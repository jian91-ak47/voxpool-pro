# 极简静态文件服务器，零依赖
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8765
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$port/")
$listener.Start()
Write-Host "Serving $root on http://127.0.0.1:$port/"

$mime = @{
  '.html'='text/html; charset=utf-8'
  '.js'  ='application/javascript; charset=utf-8'
  '.mjs' ='application/javascript; charset=utf-8'
  '.css' ='text/css; charset=utf-8'
  '.json'='application/json'
  '.png' ='image/png'
  '.jpg' ='image/jpeg'
  '.svg' ='image/svg+xml'
  '.webp'='image/webp'
  '.ico' ='image/x-icon'
  '.wasm'='application/wasm'
  '.txt' ='text/plain; charset=utf-8'
  '.webmanifest'='application/manifest+json'
}

while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
  } catch { break }
  $path = $ctx.Request.Url.LocalPath
  if ($path -eq '/') { $path = '/index.html' }
  $file = Join-Path $root ($path.TrimStart('/') -replace '/','\')
  if (Test-Path -LiteralPath $file -PathType Leaf) {
    $ext = [IO.Path]::GetExtension($file).ToLower()
    $ct = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
    $bytes = [IO.File]::ReadAllBytes($file)
    $ctx.Response.ContentType = $ct
    $ctx.Response.ContentLength64 = $bytes.Length
    # 允许跨域 module worker
    $ctx.Response.Headers.Add('Cross-Origin-Opener-Policy','same-origin')
    $ctx.Response.Headers.Add('Cross-Origin-Embedder-Policy','require-corp')
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
  } else {
    $ctx.Response.StatusCode = 404
  }
  $ctx.Response.Close()
}
