@echo off
title VOXPOOL Low-Spec Edition
cd /d "%~dp0"
echo ============================================
echo   VOXPOOL - Low Spec Edition
echo ============================================
echo.
echo Starting local server...
start "" /min powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
timeout /t 2 /nobreak >nul
echo Opening browser...
start "" "http://127.0.0.1:8765/index.html"
echo.
echo If black screen: use latest Chrome or Edge.
echo Close this window after game loads.
echo.
pause
